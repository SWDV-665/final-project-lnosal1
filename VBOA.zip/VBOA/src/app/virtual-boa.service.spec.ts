import { TestBed } from '@angular/core/testing';

import { VirtualBOAService } from './virtual-boa.service';

describe('VirtualBOAService', () => {
  let service: VirtualBOAService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(VirtualBOAService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

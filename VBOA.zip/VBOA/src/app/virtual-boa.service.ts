import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class VirtualBOAService {
  items = [
    {name: "Wired Funds - John Doe",
    status: "Awaiting Approval",
    value: 0.7
  },
  {name: "Estate Planning - Marilyn Monroe",
  status: "Designate Beneficiaries",
  value: 0.25
  }, 
  {name: "Open Retirement Account - Jane Smith",
  status: "Sign LOA",
  value: 0.80
}, 
{name: "Buy Variable Life Insurance - Mickey Mouse",
status: "Medical Exam",
value: 0.9
}, 
{name: "Open Brokerage Account - Elon Musk",
status: "Awaiting Funding",
value: 0.75
}, 
{name: "Annual Account Review - Iron Man",
status: "Awaiting Risk Tolerance Questionnaire",
value: 0.15
},

  ];

  constructor() { }
}
